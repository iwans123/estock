<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header text-secondary fs-3 fw-bold">List Item</div>

                <div class="card-body">
                    <div class="mb-3 d-flex justify-content-between">
                        <div class="">
                            <a href="<?php echo e(route('item.create')); ?>" class="btn btn-primary">Tambah Item</a>
                            <a href="<?php echo e(route('category.index')); ?>" class="btn btn-info">Kategori</a>
                        </div>
                        <div class="">
                            <?php echo Form::open(['route' => 'item.index', 'method' => 'GET']); ?>

                            <div class="input-group">
                                <?php echo Form::text('search', request('search'), [
                                    'class' => 'form-control',
                                    'placeholder' => 'Cari...',
                                    'autofocus' => true,
                                    'onfocus' => 'this.select()',
                                ]); ?>

                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-primary">Cari</button>
                                </div>
                            </div>
                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                    <div class="table-container">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Kode Barang</th>
                                        <th scope="col">Nama Barang</th>
                                        <th scope="col">Nomor Part</th>
                                        <th scope="col">Kategori</th>
                                        <th scope="col">Harga</th>
                                        
                                        
                                        <th scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $counter = 1;
                                    ?>
                                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($counter++); ?></th>
                                            <td><?php echo DNS1D::getbarcodeHTML("$item->code", 'C39'); ?>

                                                p - <?php echo e($item->code); ?></td>
                                            <td><?php echo e($item->name); ?></td>
                                            <td><?php echo e($item->part_number); ?></td>
                                            <td><?php echo e($item->category->name); ?></td>
                                            <td>
                                                <div>
                                                    <div class="text-primary fw-bold">
                                                        <?php echo e(formatRupiah($item->price_first, true)); ?></div>
                                                    <div>L - <?php echo e($item->price_code); ?></div>
                                                </div>
                                                <span></span>
                                                <span></span>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('item.generateBarcode', $item->id)); ?>"
                                                    class="btn btn-success">Print</a>
                                                <?php echo $__env->make('item_detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                                <a href="<?php echo e(route('item.edit', $item->id)); ?>"
                                                    class="btn btn-primary">Edit</a>
                                                
                                                <button class="btn btn-danger"
                                                    onclick="deletePost(<?php echo e($item->id); ?>)">Hapus</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    <script>
        function deletePost(postId) {
            Swal.fire({
                title: 'Anda yakin?',
                text: "Anda tidak akan dapat mengembalikan ini!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, hapus!'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Jika pengguna menekan "Ya, hapus", arahkan ke rute delete
                    window.location = '/item/delete/' + postId;
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main_adminkit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\e-stock\e-stock\resources\views/item.blade.php ENDPATH**/ ?>