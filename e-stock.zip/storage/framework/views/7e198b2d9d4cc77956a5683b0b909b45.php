<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
    .text-center {
        text-align: center;
    }
</style>

<body>
    
    <table width="100%" style="margin: 0 auto;">
        <tr>
            <td style="text-align: center">
                <p style="font-size: 28px;font-weight: bold;">
                    <?php echo e($item->name); ?>


                </p>
                <?php echo DNS1D::getbarcodeHTML($item->code, 'C39', 3, 150); ?>

                <h1 style="font-size: 24px;font-weight: bold;"><?php echo e($item->code); ?></h1>
                <h1>(<?php echo e(formatRupiah($item->price_first, true)); ?>) (<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>)</h1>
            </td>
        </tr>
    </table>
    
</body>

</html>
<?php /**PATH D:\e-stock\e-stock\resources\views/pdf/barcode.blade.php ENDPATH**/ ?>