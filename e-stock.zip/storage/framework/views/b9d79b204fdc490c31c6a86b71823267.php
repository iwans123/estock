<div class="card">

    <div class="card-header text-secondary fs-3 fw-bold">List Item</div>

    <div class="card-body">
        <div class="mb-3 d-flex justify-content-between">
            <div class="">
                <?php echo Form::open(['route' => 'order.index', 'method' => 'GET']); ?>

                <div class="input-group">
                    <?php echo Form::text('search', request('search'), ['class' => 'form-control', 'placeholder' => 'Cari...']); ?>

                    <div class="input-group-append">
                        <button type="submit" class="btn btn-primary">Cari</button>
                    </div>
                </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Kode</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $counter = 1;
                    ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($counter++); ?></th>
                            <td><?php echo e($stock->item->code); ?></td>
                            <td><?php echo e($stock->item->name); ?></td>
                            <td>
                                <?php echo Form::open(['route' => 'order.index', 'method' => 'GET']); ?>


                                <div class="form-group">
                                    <?php echo Form::text('search_item', $stock->item->code, [
                                        'hidden' => true,
                                    ]); ?>

                                </div>
                                <?php echo Form::submit('Tambah', ['class' => 'btn btn-primary']); ?>

                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH D:\e-stock\e-stock\resources\views/order/item_list.blade.php ENDPATH**/ ?>