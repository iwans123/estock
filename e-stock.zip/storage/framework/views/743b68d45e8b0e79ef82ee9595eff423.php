<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
    <meta name="author" content="AdminKit">
    <meta name="keywords"
        content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="shortcut icon" href="img/icons/icon-48x48.png" />

    <link rel="canonical" href="https://demo-basic.adminkit.io/pages-blank.html" />

    <title>e-stock</title>

    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('adminkit/css/app.css')); ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        html,
        body {
            height: 100%;
            margin: 0;
            padding: 0;
        }

        .table-container {
            display: flex;
            flex-direction: column;
            height: 100vh;
        }

        .table-responsive {
            flex: 1;
            overflow-y: auto;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <nav id="sidebar" class="sidebar js-sidebar">
            <div class="sidebar-content js-simplebar">
                <a class="sidebar-brand">
                    <span class="align-middle">e-Stock</span>
                </a>
                <ul class="sidebar-nav">
                    <li class="sidebar-header">
                        Pages
                    </li>

                    <?php if (\Illuminate\Support\Facades\Blade::check('hasrole', 'admin')): ?>
                        <li class="sidebar-item <?php echo e(Route::is('dashboard.*') ? 'active' : ''); ?>">
                            <a class="sidebar-link" href="<?php echo e(route('dashboard.index')); ?>">
                                <i class="align-middle" data-feather="home"></i> <span class="align-middle">Dashboard</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (\Illuminate\Support\Facades\Blade::check('hasrole', 'admin|toko-1')): ?>
                        <li class="sidebar-item <?php echo e(Route::is('item.*') ? 'active' : ''); ?>">
                            <a class="sidebar-link" href="<?php echo e(route('item.index')); ?>">
                                <i class="align-middle" data-feather="file"></i> <span class="align-middle">Item</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <li class="sidebar-item <?php echo e(Route::is('first-shop.*') ? 'active' : ''); ?>">
                        <a class="sidebar-link" href="<?php echo e(route('first-shop.index')); ?>">
                            <i class="align-middle" data-feather="user"></i> <span class="align-middle">Toko 1</span>
                        </a>
                    </li>

                    <li class="sidebar-item <?php echo e(Route::is('second-shop.*') ? 'active' : ''); ?>">
                        <a class="sidebar-link" href="<?php echo e(route('second-shop.index')); ?>">
                            <i class="align-middle" data-feather="users"></i> <span class="align-middle">Toko 2</span>
                        </a>
                    </li>

                    <li class="sidebar-item <?php echo e(Route::is('warehouse.*') ? 'active' : ''); ?>">
                        <a class="sidebar-link" href="<?php echo e(route('warehouse.index')); ?>">
                            <i class="align-middle" data-feather="server"></i> <span class="align-middle">Gudang</span>
                        </a>
                    </li>

                    

                    <li class="sidebar-header">
                        Transaksi
                    </li>

                    <li class="sidebar-item <?php echo e(Route::is('order.*') ? 'active' : ''); ?>">
                        <a class="sidebar-link" href="<?php echo e(route('order.index')); ?>">
                            <i class="align-middle" data-feather="shopping-cart"></i> <span
                                class="align-middle">Order</span>
                        </a>
                    </li>

                    
            </div>
        </nav>

        <div class="main">
            <nav class="navbar navbar-expand navbar-light navbar-bg">
                <a class="sidebar-toggle js-sidebar-toggle">
                    <i class="hamburger align-self-center"></i>
                </a>

                <div class="navbar-collapse collapse">
                    <ul class="navbar-nav navbar-align">
                        
                        <li class="nav-item dropdown">
                            <a class="nav-icon dropdown-toggle d-inline-block d-sm-none" href="#"
                                data-bs-toggle="dropdown">
                                <i class="align-middle" data-feather="settings"></i>
                            </a>

                            <a class="nav-link dropdown-toggle d-none d-sm-inline-block" href="#"
                                data-bs-toggle="dropdown">
                                <span class="text-secondary text-uppercase fw-bold"><?php echo e(Auth::user()->name); ?></span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end">
                                
                                <a class="dropdown-item" href="<?php echo e(route('logout-user')); ?>">Log out</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>

            <main class="content">

                <?php echo $__env->yieldContent('content'); ?>
            </main>

            <footer class="footer">
                <div class="container-fluid">
                    <div class="row text-muted">
                        <div class="col-6 text-start">
                            <p class="mb-0">
                                <a class="text-muted" href="https://adminkit.io/"
                                    target="_blank"><strong>AdminKit</strong></a> - <a class="text-muted"
                                    href="https://adminkit.io/" target="_blank"><strong>Bootstrap Admin
                                        Template</strong></a> &copy;
                            </p>
                        </div>
                        
                    </div>
                </div>
            </footer>
        </div>
    </div>
</body>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src=<?php echo e(asset('adminkit/js/app.js')); ?>></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script>
    <?php if(Session::has('success')): ?>

        toastr.success("<?php echo e(Session::get('success')); ?>", '<?php echo e(Auth::user()->name); ?>')
        // toastr.success('Have fun storming the castle!', 'Miracle Max Says')
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        toastr.error("<?php echo e(Session::get('error')); ?>")
    <?php endif; ?>
</script>

</html>
<?php /**PATH D:\e-stock\e-stock\resources\views/layouts/main_adminkit.blade.php ENDPATH**/ ?>