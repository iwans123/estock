<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#receiving<?php echo e($category->id); ?>">
    Edit
</button>

<!-- Modal -->
<div class="modal fade" id="receiving<?php echo e($category->id); ?>" tabindex="-1" role="dialog" aria-labelledby="receivingLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="receivingLabel">Edit Kategori</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="modal-body">
                <?php echo Form::model($category, ['route' => ['category.update', $category->id], 'method' => 'PUT']); ?>

                <div class="form-group mb-2">
                    <?php echo Form::label('name', 'Kategori'); ?>

                    <?php echo Form::text('name', null, [
                        'class' => 'form-control',
                        'placeholder' => 'Masukkan Kategori',
                    ]); ?>

                </div>
            </div>
            <div class="modal-footer">
                <?php echo Form::submit('Simpan', ['class' => 'btn btn-primary']); ?>

                <?php echo Form::close(); ?>

                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\e-stock\e-stock\resources\views/category/edit_modal.blade.php ENDPATH**/ ?>