<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#receiving<?php echo e($stock->id); ?>">
    Masuk
</button>

<!-- Modal -->
<div class="modal fade" id="receiving<?php echo e($stock->id); ?>" tabindex="-1" role="dialog" aria-labelledby="receivingLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="receivingLabel">Barang masuk</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="modal-body">
                <?php echo Form::model($stock, ['route' => ['second-shop.update', $stock->id], 'method' => 'PUT']); ?>

                <div class="form-group mb-2">
                    <?php echo Form::label('name', 'Barang'); ?>

                    <?php echo Form::text('item_id', $stock->item->name, [
                        'class' => 'form-control',
                        'placeholder' => 'Enter Name',
                        'disabled' => 'disabled',
                    ]); ?>

                </div>
                
                <div class="form-group mb-2">
                    <?php echo Form::label('quantity', 'quantity'); ?>

                    <?php echo Form::number('stock', null, [
                        'class' => 'form-control',
                        'placeholder' => 'Masukkan quantity',
                    ]); ?>

                </div>
            </div>
            <div class="modal-footer">
                <?php echo Form::submit('Simpan', ['class' => 'btn btn-primary']); ?>

                <?php echo Form::close(); ?>

                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\e-stock\e-stock\resources\views/second_shop/receiving_modal.blade.php ENDPATH**/ ?>