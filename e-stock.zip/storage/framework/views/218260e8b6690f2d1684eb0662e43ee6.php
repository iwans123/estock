

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-4">
            <?php echo $__env->make('order.item_list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-md-8">
            <?php echo $__env->make('order.order_list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main_adminkit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\e-stock\e-stock\resources\views/order/index.blade.php ENDPATH**/ ?>