<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="card">
                <div class="card-header text-secondary fs-3 fw-bold"><?php echo e(isset($item) ? 'Edit Item' : 'Tambah Item'); ?></div>

                <div class="card-body p-6">
                    <?php if(isset($item)): ?>
                        <?php echo Form::model($item, ['route' => ['item.update', $item->id], 'method' => 'PUT']); ?>

                    <?php else: ?>
                        <?php echo Form::open(['route' => 'item.store']); ?>

                    <?php endif; ?>

                    

                    <div class="form-group mb-2">
                        <?php echo Form::label('name', 'Nama Barang'); ?>

                        <span class="text-danger">*</span>
                        <?php echo Form::text('name', null, ['class' => 'form-control', 'required', 'placeholder' => 'Masukkan nama barang']); ?>

                        <span class="text-danger"><?php echo $errors->first('name'); ?></span>
                    </div>

                    <?php if(!isset($item)): ?>
                        
                    <?php endif; ?>
                    <div class="form-group form-inline mb-2">
                        <?php echo Form::label('category_id', 'Kategori'); ?>

                        <span class="text-danger">*</span>
                        <div class="input-group">
                            <?php echo Form::select('category_id', $categories->pluck('name', 'id'), null, [
                                'class' => 'form-control',
                                'placeholder' => 'Pilih Kategori',
                                'required',
                            ]); ?>

                            <div class="input-group-append">
                                <a href="<?php echo e(route('category.index')); ?>" class="btn btn-info">Tambah Kategori</a>
                            </div>
                        </div>
                        <span>
                        </span>
                        <span class="text-danger"><?php echo $errors->first('category_id'); ?></span>
                    </div>



                    <div class="form-group mb-2">
                        <?php echo Form::label('part_number', 'Part Number'); ?>

                        <?php echo Form::text('part_number', null, ['class' => 'form-control', 'placeholder' => 'Masukkan part number']); ?>

                        <span class="text-danger"><?php echo $errors->first('part_number'); ?></span>
                    </div>

                    <div class="form-group mb-2">
                        <?php echo Form::label('price_code', 'List Harga'); ?>

                        <?php echo Form::text('price_code', null, ['class' => 'form-control', 'placeholder' => 'Masukkan list harga']); ?>

                        <span class="text-danger"><?php echo $errors->first('price_code'); ?></span>
                    </div>

                    <div class="form-group mb-2">
                        <?php echo Form::label('price_first', 'Harga Jual'); ?>

                        <span class="text-danger">*</span>
                        <?php echo Form::number('price_first', null, [
                            'class' => 'form-control',
                            'required',
                            'placeholder' => 'Masukkan harga jual',
                        ]); ?>

                        <span class="text-danger"><?php echo $errors->first('price_first'); ?></span>
                    </div>

                    <div class="form-group mb-2">
                        <?php echo Form::label('price_second', 'Harga Jual 2'); ?>

                        <?php echo Form::number('price_second', null, ['class' => 'form-control', 'placeholder' => 'Masukkan harga potongan']); ?>

                        <span class="text-danger"><?php echo $errors->first('price_second'); ?></span>
                    </div>

                    <div class="form-group mb-2">
                        <?php echo Form::label('description', 'Deskripsi'); ?>

                        <?php echo Form::textarea('description', null, ['class' => 'form-control', 'rows' => 3, 'cols' => 50]); ?>

                        <span class="text-danger"><?php echo $errors->first('description'); ?></span>
                    </div>

                    <?php echo Form::submit(isset($item) ? 'Simpan Perubahan' : 'Tambah', ['class' => 'btn btn-primary']); ?>

                    <?php echo Form::close(); ?>


                    <div class="mt-3">
                        <span class="text-danger">*</span>
                        <span>wajib diisi</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main_adminkit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\e-stock\e-stock\resources\views/item_form.blade.php ENDPATH**/ ?>