<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header text-secondary fs-3 fw-bold">List Stok Toko 1</div>

                <div class="card-body">
                    <div class="mb-3 d-flex justify-content-between">
                        
                        <div class="">
                            <?php echo Form::open(['route' => 'first-shop.index', 'method' => 'GET']); ?>

                            <div class="input-group">
                                <?php echo Form::text('search', request('search'), [
                                    'class' => 'form-control',
                                    'placeholder' => 'Cari...',
                                    'autofocus',
                                    'onfocus' => 'this.select()',
                                ]); ?>

                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-primary">Cari</button>
                                </div>
                            </div>
                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                    <div class="table-container">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Kode Barang</th>
                                        <th scope="col">Nama Barang</th>
                                        <th scope="col">Nomor Part</th>
                                        <th scope="col">Kategori</th>
                                        <th scope="col">Stok</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Harga</th>
                                        
                                        <?php if (\Illuminate\Support\Facades\Blade::check('hasrole', 'admin|toko-1')): ?>
                                            <th scope="col">Aksi</th>
                                        <?php endif; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $counter = 1;
                                    ?>
                                    <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($counter++); ?></th>
                                            <td><?php echo e($stock->item->code); ?></td>
                                            <td><?php echo e($stock->item->name); ?></td>
                                            <td><?php echo e($stock->item->part_number); ?></td>
                                            <td><?php echo e($stock->item->category->name); ?></td>
                                            <td><?php echo e($stock->stock); ?></td>
                                            <td><span
                                                    class="badge <?php echo e($stock->status == 'aktif' ? 'bg-success' : 'bg-danger'); ?>"><?php echo e($stock->status); ?></span>
                                            </td>
                                            <td class="text-primary fw-bold">
                                                <?php echo e(formatRupiah($stock->item->price_first, true)); ?>

                                            </td>
                                            
                                            <td>
                                                <?php echo $__env->make('first_shop.detail_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <?php if (\Illuminate\Support\Facades\Blade::check('hasrole', 'admin|toko-1')): ?>
                                                    <?php echo $__env->make('first_shop.receiving_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    <?php echo $__env->make('first_shop.transfer_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main_adminkit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\e-stock\e-stock\resources\views/first_shop/index.blade.php ENDPATH**/ ?>